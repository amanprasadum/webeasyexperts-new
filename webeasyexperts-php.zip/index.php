<!DOCTYPE html>
<html lang="en">

<head>
  <script>
    (function (w, d, s, l, i) {
      w[l] = w[l] || []; w[l].push({
        'gtm.start':
          new Date().getTime(), event: 'gtm.js'
      }); var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
          'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-PFD9CDQP');</script>
  <!-- End Google Tag Manager -->
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Custom & Scalable Website Experts—Built for Businesses Worldwide</title>
  <!-- Favicon -->
  <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon-16x16.png">


  <!-- Apple -->
  <link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">

  <!-- Android -->
  <link rel="icon" type="image/png" sizes="192x192" href="assets/images/android-chrome-192x192.png">
  <link rel="icon" type="image/png" sizes="512x512" href="assets/images/android-chrome-512x512.png">

  <meta name="description"
    content="Web EASY Experts—A team of expert website designers and developers from India, delivering custom, scalable, and SEO-friendly websites for businesses worldwide.">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
  <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet" />
  <link
    href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600&display=swap"
    rel="stylesheet" />

  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/header.css">
  <link rel="stylesheet" href="assets/css/footer.css">
</head>

<body>
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PFD9CDQP" height="0" width="0"
      style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

  <?php $base = ""; $home = ""; include $base . "header.php"; ?><!-- ══════ HERO ══════ -->
  <section class="hero-section">
    <div class="hero-blob hero-blob-1"></div>
    <div class="hero-blob hero-blob-2"></div>
    <div class="container">
      <div class="row align-items-center g-5">
        <div class="col-lg-6" data-aos="fade-up">
          <div class="hero-badge"><i class="bi bi-award-fill"></i> Trusted by Businesses Worldwide</div>
          <h1 class="hero-title">Custom & Scalable Website Experts<br><span class="accent">Built for Businesses
              Worldwide</span></h1>
          <p class="hero-subtitle">A team of expert website designers and developers from India, serving clients
            worldwide.</p>
          <div class="hero-actions">
            <a href="#contact" class="btn btn-brand">Get a Free Consultentation <i
                class="bi bi-arrow-right ms-2"></i></a>
            <a href="#portfolio" class="btn btn-outline-soft d-flex align-items-center gap-2"><i
                class="bi bi-eye-fill text-danger"></i> View Our Work</a>
          </div>
          <!-- <div class="hero-trust">
            <span><i class="bi bi-check-circle-fill text-success"></i> Custom Web Design & Development</span>
            <span><i class="bi bi-check-circle-fill text-success"></i> Fast, SEO-Friendly & AI-Ready</span>
            <span><i class="bi bi-check-circle-fill text-success"></i> Built for All Devices & Screen Sizes</span>
            <span><i class="bi bi-check-circle-fill text-success"></i> Trusted by Global Clients Since 2023</span>
          </div> -->
        </div>
        <div class="col-lg-6" data-aos="fade-up" data-aos-delay="150">
          <div class="hero-visual position-relative">
            <div class="hero-card">
              <div class="hero-card-topbar">
                <div class="dot dot-r"></div>
                <div class="dot dot-y"></div>
                <div class="dot dot-g"></div>
                <div class="ms-2"
                  style="font-size:0.72rem;color:var(--t500);background:var(--muted);padding:2px 12px;border-radius:20px;flex:1;max-width:200px;text-align:center">
                  webesyexperts.com/dashboard</div>
              </div>
              <div class="hero-card-body">
                <div class="row g-3 mb-3">
                  <div class="col-4">
                    <div class="mini-stat">
                      <div class="lbl">Organic Traffic</div>
                      <div class="val">38K</div>
                      <div class="dlta up mt-1"><i class="bi bi-arrow-up-short"></i>42%</div>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="mini-stat">
                      <div class="lbl">Leads Generated</div>
                      <div class="val">284</div>
                      <div class="dlta up mt-1"><i class="bi bi-arrow-up-short"></i>18%</div>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="mini-stat">
                      <div class="lbl">Ad ROAS</div>
                      <div class="val">5.2x</div>
                      <div class="dlta up mt-1"><i class="bi bi-arrow-up-short"></i>0.8x</div>
                    </div>
                  </div>
                </div>
                <div style="border:1px solid var(--border);border-radius:10px;overflow:hidden">
                  <div
                    style="padding:0.6rem 1rem;background:var(--subtle);font-size:0.72rem;font-weight:700;color:var(--t500);border-bottom:1px solid var(--border)">
                    ACTIVE PROJECTS</div>
                  <div
                    style="padding:0.65rem 1rem;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border)">
                    <div style="display:flex;align-items:center;gap:0.6rem"><i class="bi bi-check-circle-fill"
                        style="color:#16A34A;font-size:0.85rem"></i><span
                        style="font-size:0.82rem;font-weight:500;color:var(--t900)">RetailPlus — E-Commerce Store</span>
                    </div>
                    <span
                      style="font-size:0.68rem;background:#DCFCE7;color:#15803D;padding:1px 8px;border-radius:20px;font-weight:600">Live</span>
                  </div>
                  <div
                    style="padding:0.65rem 1rem;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border);background:rgba(229,57,53,0.025)">
                    <div style="display:flex;align-items:center;gap:0.6rem"><i class="bi bi-circle"
                        style="color:var(--red);font-size:0.85rem"></i><span
                        style="font-size:0.82rem;font-weight:500;color:var(--t900)">MedCare Clinic — Website
                        Redesign</span></div>
                    <span
                      style="font-size:0.68rem;background:#FEE2E2;color:#DC2626;padding:1px 8px;border-radius:20px;font-weight:600">In
                      Progress</span>
                  </div>
                  <div style="padding:0.65rem 1rem;display:flex;justify-content:space-between;align-items:center">
                    <div style="display:flex;align-items:center;gap:0.6rem"><i class="bi bi-circle"
                        style="color:var(--t300);font-size:0.85rem"></i><span
                        style="font-size:0.82rem;font-weight:500;color:var(--t900)">BuildRight Construction — SEO +
                        Web</span></div>
                    <span
                      style="font-size:0.68rem;background:var(--muted);color:var(--t500);padding:1px 8px;border-radius:20px;font-weight:600">Design</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="floating-notif">
              <div class="ndot"></div><i class="bi bi-graph-up-arrow text-danger"></i>Client site just hit Page 1 on
              Google 🎉
            </div>
          </div>
        </div>
        <!-- <div class="col-lg-6" data-aos="fade-up" data-aos-delay="150">
          <div class="hero-visual position-relative">
            <div class="hero-card">
              <div class="hero-card-topbar">
                <div class="dot dot-r"></div>
                <div class="dot dot-y"></div>
                <div class="dot dot-g"></div>
                <div class="ms-2"
                  style="font-size:0.72rem;color:var(--t500);background:var(--muted);padding:2px 12px;border-radius:20px;flex:1;max-width:200px;text-align:center">
                  webesyexperts.com/dashboard</div>
              </div>
              <div class="hero-card-body">
                <div class="row g-3 mb-3">
                  <div class="col-4">
                    <div class="mini-stat">
                      <div class="lbl">Organic Traffic</div>
                      <div class="val">38K</div>
                      <div class="dlta up mt-1"><i class="bi bi-arrow-up-short"></i>42%</div>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="mini-stat">
                      <div class="lbl">Leads Generated</div>
                      <div class="val">284</div>
                      <div class="dlta up mt-1"><i class="bi bi-arrow-up-short"></i>18%</div>
                    </div>
                  </div>
                  <div class="col-4">
                    <div class="mini-stat">
                      <div class="lbl">Ad ROAS</div>
                      <div class="val">5.2x</div>
                      <div class="dlta up mt-1"><i class="bi bi-arrow-up-short"></i>0.8x</div>
                    </div>
                  </div>
                </div>
                <div style="border:1px solid var(--border);border-radius:10px;overflow:hidden">
                  <div
                    style="padding:0.6rem 1rem;background:var(--subtle);font-size:0.72rem;font-weight:700;color:var(--t500);border-bottom:1px solid var(--border)">
                    ACTIVE PROJECTS</div>

                  <div
                    style="padding:0.65rem 1rem;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border)">
                    <div style="display:flex;align-items:center;gap:0.6rem">
                      <i class="bi bi-check-circle-fill" style="color:#16A34A;font-size:0.85rem"></i>
                      <span style="font-size:0.82rem;font-weight:500;color:var(--t900)">
                        Epic Loft Conversion — Website
                      </span>
                    </div>
                    <span
                      style="font-size:0.68rem;background:#DCFCE7;color:#15803D;padding:1px 8px;border-radius:20px;font-weight:600">
                      Live
                    </span>
                  </div>

                  <div
                    style="padding:0.65rem 1rem;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border)">
                    <div style="display:flex;align-items:center;gap:0.6rem">
                      <i class="bi bi-check-circle-fill" style="color:#16A34A;font-size:0.85rem"></i>
                      <span style="font-size:0.82rem;font-weight:500;color:var(--t900)">
                        Maalaxmi Export — Rice Export Website
                      </span>
                    </div>
                    <span
                      style="font-size:0.68rem;background:#DCFCE7;color:#15803D;padding:1px 8px;border-radius:20px;font-weight:600">
                      Live
                    </span>
                  </div>

                  <div
                    style="padding:0.65rem 1rem;display:flex;justify-content:space-between;align-items:center;background:rgba(229,57,53,0.025)">
                    <div style="display:flex;align-items:center;gap:0.6rem">
                      <i class="bi bi-circle" style="color:var(--red);font-size:0.85rem"></i>
                      <span style="font-size:0.82rem;font-weight:500;color:var(--t900)">
                        Bexily ERP Services — Website
                      </span>
                    </div>

                    <span
                      style="font-size:0.68rem;background:#FEE2E2;color:#278cff;padding:1px 8px;border-radius:20px;font-weight:600">
                      In Progress
                    </span>
                  </div>
                  <div
                    style="padding:0.65rem 1rem;display:flex;justify-content:space-between;align-items:center;background:rgba(229,57,53,0.025)">
                    <div style="display:flex;align-items:center;gap:0.6rem">
                      <i class="bi bi-circle" style="color:var(--red);font-size:0.85rem"></i>
                      <span style="font-size:0.82rem;font-weight:500;color:var(--t900)">
                        Pavitramitti Nursery — Website
                      </span>
                    </div>
                    <span
                      style="font-size:0.68rem;background:#FEE2E2;color:#278cff;padding:1px 8px;border-radius:20px;font-weight:600">
                      In Progress
                    </span>
                  </div>

                </div>
              </div>
            </div>
            <div class="floating-notif">
              <div class="ndot"></div><i class="bi bi-graph-up-arrow text-danger"></i>Client site just hit Page 1 on
              Google 🎉
            </div>
          </div>
        </div> 
        <!-- <div class="col-lg-6 p-0" data-aos="fade-up" data-aos-delay="150">  
          <img src="assets/images/hero4.png" alt="" srcset="" class="img-fluid">
        </div> -->
      </div>
    </div>
  </section>

  <!-- ══════ LOGOS MARQUEE ══════ -->
  <section class="logos-section">
    <div class="container">
      <div class="logos-label">Trusted by 500+ businesses across the globe</div>
    </div>
    <div class="marquee-track">
      <div class="marquee-inner">
        <div class="logo-pill"><i class="bi bi-building-fill" style="color:#2563EB"></i>RetailPlus</div>
        <div class="logo-pill"><i class="bi bi-hospital-fill" style="color:#16A34A"></i>MedCare Clinic</div>
        <div class="logo-pill"><i class="bi bi-bag-fill" style="color:#D97706"></i>FashionHub</div>
        <div class="logo-pill"><i class="bi bi-mortarboard-fill" style="color:#7C3AED"></i>EduSmart</div>
        <div class="logo-pill"><i class="bi bi-tools" style="color:#0D9488"></i>BuildRight</div>
        <div class="logo-pill"><i class="bi bi-cup-hot-fill" style="color:#EA580C"></i>CafeBliss</div>
        <div class="logo-pill"><i class="bi bi-car-front-fill" style="color:#0284C7"></i>AutoDrive</div>
        <div class="logo-pill"><i class="bi bi-gem" style="color:#EC4899"></i>LuxeStore</div>
        <div class="logo-pill"><i class="bi bi-building-fill" style="color:#2563EB"></i>RetailPlus</div>
        <div class="logo-pill"><i class="bi bi-hospital-fill" style="color:#16A34A"></i>MedCare Clinic</div>
        <div class="logo-pill"><i class="bi bi-bag-fill" style="color:#D97706"></i>FashionHub</div>
        <div class="logo-pill"><i class="bi bi-mortarboard-fill" style="color:#7C3AED"></i>EduSmart</div>
        <div class="logo-pill"><i class="bi bi-tools" style="color:#0D9488"></i>BuildRight</div>
        <div class="logo-pill"><i class="bi bi-cup-hot-fill" style="color:#EA580C"></i>CafeBliss</div>
        <div class="logo-pill"><i class="bi bi-car-front-fill" style="color:#0284C7"></i>AutoDrive</div>
        <div class="logo-pill"><i class="bi bi-gem" style="color:#EC4899"></i>LuxeStore</div>
      </div>
    </div>
  </section>

  <!-- ══════ SERVICES ══════ -->
  <section class="section" id="services">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <div class="section-label mx-auto"><i class="bi bi-grid-fill"></i> Our Services</div>
        <h2 class="section-title">Our Web Experts Specialize in<br> <span class="accent"> Technologies Including</span>
        </h2>
        <p class="section-sub mx-auto">Our expert web designers and developers use the latest tools and technologies to
          build websites that are fast, secure, and scalable.</p>
      </div>
      <div class="row g-4">

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="0">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#FEE2E2;color:var(--red);margin:0 auto 1.25rem;">
              <i class="bi bi-laptop"></i>
            </div>
            <div class="serv-title">Core Web Development</div>
            <div class="serv-desc">Our web development team builds websites that give you a dependable online presence
              that scales as your business grows locally and globally.</div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="60">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#EFF6FF;color:#2563EB;margin:0 auto 1.25rem;">
              <i class="bi bi-braces-asterisk"></i>
            </div>
            <div class="serv-title">Frontend Development</div>
            <div class="serv-desc">Your customers deserve a site that looks great and feels effortless. Our frontend
              development team designs modern, responsive interfaces that make browsing a pleasure.</div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="120">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#F0FDF4;color:#16A34A;margin:0 auto 1.25rem;">
              <i class="bi bi-server"></i>
            </div>
            <div class="serv-title">Backend Development</div>
            <div class="serv-desc">Behind the scenes, our backend development team create secure, stable systems that
              keep your website fast, dependable, and ready for anything.</div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="0">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#F0FDFA;color:#0D9488;margin:0 auto 1.25rem;">
              <i class="bi bi-shop"></i>
            </div>
            <div class="serv-title">eCommerce Development</div>
            <div class="serv-desc">Selling online should be simple. Our eCommerce development services craft online
              stores that make shopping easy for your customers and managing sales stress-free for you.</div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="60">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#FFF7ED;color:#EA580C;margin:0 auto 1.25rem;">
              <i class="bi bi-grid-fill"></i>
            </div>
            <div class="serv-title">CMS & Website Builders</div>
            <div class="serv-desc">Take control of your content with our CMS & website builder services. We set up a CMS
              that is easy to operate, so you can make changes anytime without needing tech support.</div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="120">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#F5F3FF;color:#7C3AED;margin:0 auto 1.25rem;">
              <i class="bi bi-stars"></i>
            </div>
            <div class="serv-title">Advanced & Trending Solutions</div>
            <div class="serv-desc">Our advanced and trending web solution helps your business stay ahead of the
              competition. We use the latest tools and technologies to keep your website fresh, modern, and competitive.
            </div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="0">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#FFF1F2;color:#E11D48;margin:0 auto 1.25rem;">
              <i class="bi bi-palette-fill"></i>
            </div>
            <div class="serv-title">Design & Experience</div>
            <div class="serv-desc">First impressions of your website matter. Our experienced designers create clean,
              user-friendly designs that leave visitors impressed and eager to return.</div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

        <div class="col-md-6 col-lg-4 col-xl-3" data-aos="fade-up" data-aos-delay="60">
          <div class="serv-card" style="text-align:center;">
            <div class="serv-icon" style="background:#ECFEFF;color:#0891B2;margin:0 auto 1.25rem;">
              <i class="bi bi-plug-fill"></i>
            </div>
            <div class="serv-title">Integration & Optimization</div>
            <div class="serv-desc">Your website should work smarter, not harder. Our expertise connects the tools you
              use and fine-tunes performance for a faster, smoother experience.</div>
            <a href="#" class="serv-link" style="justify-content:center;">Explore More <i
                class="bi bi-arrow-right"></i></a>
          </div>
        </div>

      </div>
      <!-- <p class="text-center mt-4" style="font-size:.82rem;color:var(--t500)">
        <i class="bi bi-info-circle text-danger me-1"></i> Each technology can be explored in detail on its dedicated
        page.
        <a href="#" style="color:var(--red);font-weight:600">Read More →</a>
      </p> -->
    </div>
  </section>

  <!-- ══════ INDUSTRIES ══════ -->
  <section class="section" style="background:var(--white);border-top:1px solid var(--border)">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <div class="section-label mx-auto"><i class="bi bi-diagram-3-fill"></i> Industries</div>
        <h2 class="section-title">Our Website Experts Serve <br>Every <span class="accent"> Major Industry
            Worldwide</span></h2>
      </div>
      <div class="row g-3">
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-cart4"></i> Grocery Stores & Supermarkets</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-phone"></i> Mobile Shops & Electronics Stores</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-bag-heart-fill"></i> Fashion & Lifestyle Boutiques</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-stars"></i> Beauty Salons & Spas</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-house-fill"></i> Furniture & Home Décor</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-gem"></i> Jewelry & Accessories</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-briefcase-fill"></i> Corporate Businesses</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-rocket-takeoff-fill"></i> Startups & Entrepreneurs</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-bank2"></i> Law Firms & Legal Services</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-calculator-fill"></i> Financial Accounting & Consultenting</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-shield-fill"></i> Insurance Companies</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-people-fill"></i> Recruitment & HR Agencies</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-cpu-fill"></i> IT & Software Companies</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-wifi"></i> Telecommunications</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-heart-pulse-fill"></i> Healthcare Technology (MedTech)</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-shop-window"></i> E-commerce & Online Marketplaces</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-cloud-fill"></i> Startups & SaaS Platforms</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-cup-hot-fill"></i> Restaurants & Cafés</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-building"></i> Hotels & Hospitality</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-airplane-fill"></i> Travel & Tourism</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-heart-pulse-fill"></i> Personal Training & Fitness Centers</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-calendar-event-fill"></i> Event Management</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-camera-reels-fill"></i> Entertainment & Media</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-building-fill-gear"></i> Construction Companies</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-compass-fill"></i> Architecture Firms</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-tools"></i> Manufacturing & Industrial Units</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-tree-fill"></i> Agriculture & Food Processing</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-truck-front-fill"></i> Logistics & Supply Chain</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-bus-front-fill"></i> Transport Companies</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-lightning-charge-fill"></i> Energy & Utilities</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-mortarboard-fill"></i> Schools & Universities</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-people-fill"></i> NGOs & Non-Profits</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-bank"></i> Government & Public Sector</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-hospital-fill"></i> Healthcare & Hospitals</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-capsule"></i> Pharmaceuticals & Biotech</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-person-badge-fill"></i> Personal Portfolios</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
          <div class="industry-pill"><i class="bi bi-box-seam-fill"></i> Product Showcase Websites</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="40">
          <div class="industry-pill"><i class="bi bi-play-circle-fill"></i> Video & Photo Showcase</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
          <div class="industry-pill"><i class="bi bi-bag-heart-fill"></i> Fashion Designers</div>
        </div>
        <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="120">
          <div class="industry-pill"><i class="bi bi-palette-fill"></i> Artists & Performers</div>
        </div>
      </div>
    </div>
  </section>

  <!-- ══════ GLOBAL REACH ══════ -->
  <section class="wexpert-global-section" id="global">
    <div class="wexpert-global-grid-bg"></div>
    <div class="container">
      <!-- Header -->
      <div class="wexpert-global-header" data-aos="fade-up">
        <div class="wexpert-global-badge">
          <i class="bi bi-globe2"></i> Global Reach
        </div>
        <h2 class="wexpert-global-heading">Global Reach, <span>Local Understanding</span></h2>
        <p class="wexpert-global-sub">We proudly serve clients worldwide while focusing on key international markets
          where digital demand is rapidly growing. Our experience working with global businesses allows us to deliver
          web solutions tailored to different industries, audiences, and regions.</p>
      </div>
      <!-- Countries label -->
      <div class="wexpert-global-countries-label" data-aos="fade-up">
        Countries We Frequently Work With
      </div>
      <!-- Countries -->
      <div class="wexpert-global-countries" data-aos="fade-up">
        <div class="wexpert-global-country"><span>United
            States</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>United
            Kingdom</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>Canada</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>Australia</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>Ireland</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>United Arab
            Emirates</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>Singapore</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>Germany</span><span class="wexpert-global-country-dot"></span></div>
        <div class="wexpert-global-country"><span>Netherlands</span><span class="wexpert-global-country-dot"></span>
        </div>
        <div class="wexpert-global-country"><span>Sweden</span><span class="wexpert-global-country-dot"></span></div>
      </div>
      <!-- Stats strip -->
      <div class="wexpert-global-stats" data-aos="fade-up">
        <div class="wexpert-global-stat">
          <div class="wexpert-global-stat-val">10<span>+</span></div>
          <div class="wexpert-global-stat-lbl">Countries Served</div>
        </div>
        <div class="wexpert-global-stat">
          <div class="wexpert-global-stat-val">500<span>+</span></div>
          <div class="wexpert-global-stat-lbl">Projects Delivered</div>
        </div>
        <div class="wexpert-global-stat">
          <div class="wexpert-global-stat-val">2023<span>~</span></div>
          <div class="wexpert-global-stat-lbl">Serving Since</div>
        </div>
      </div>

    </div>
  </section>

  <!-- ══════ PROCESS ══════ -->
  <section class="wexpert-process-section" id="process">
    <svg class="wexpert-process-bg-svg" viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice"
      xmlns="http://www.w3.org/2000/svg">

      <!-- Horizontal flowing lines -->
      <line x1="0" y1="120" x2="1440" y2="120" stroke="#E2E8F0" stroke-width="1" />
      <line x1="0" y1="120" x2="1440" y2="120" stroke="#E53935" stroke-width="1.2" class="wexpert-process-path-flow" />

      <line x1="0" y1="300" x2="1440" y2="300" stroke="#E2E8F0" stroke-width="1" />
      <line x1="0" y1="300" x2="1440" y2="300" stroke="#2563EB" stroke-width="1"
        class="wexpert-process-path-flow-slow" />

      <line x1="0" y1="480" x2="1440" y2="480" stroke="#E2E8F0" stroke-width="1" />
      <line x1="0" y1="480" x2="1440" y2="480" stroke="#E53935" stroke-width="1"
        class="wexpert-process-path-flow-reverse" />

      <line x1="0" y1="660" x2="1440" y2="660" stroke="#E2E8F0" stroke-width="1" />
      <line x1="0" y1="660" x2="1440" y2="660" stroke="#16A34A" stroke-width="1"
        class="wexpert-process-path-flow-slow" />

      <line x1="0" y1="820" x2="1440" y2="820" stroke="#E2E8F0" stroke-width="1" />
      <line x1="0" y1="820" x2="1440" y2="820" stroke="#2563EB" stroke-width="1" class="wexpert-process-path-flow" />

      <!-- Vertical flowing lines -->
      <line x1="200" y1="0" x2="200" y2="900" stroke="#E2E8F0" stroke-width="1" />
      <line x1="200" y1="0" x2="200" y2="900" stroke="#E53935" stroke-width="1"
        class="wexpert-process-path-flow-slow" />

      <line x1="500" y1="0" x2="500" y2="900" stroke="#E2E8F0" stroke-width="1" />
      <line x1="500" y1="0" x2="500" y2="900" stroke="#2563EB" stroke-width="1"
        class="wexpert-process-path-flow-reverse" />

      <line x1="900" y1="0" x2="900" y2="900" stroke="#E2E8F0" stroke-width="1" />
      <line x1="900" y1="0" x2="900" y2="900" stroke="#16A34A" stroke-width="1" class="wexpert-process-path-flow" />

      <line x1="1200" y1="0" x2="1200" y2="900" stroke="#E2E8F0" stroke-width="1" />
      <line x1="1200" y1="0" x2="1200" y2="900" stroke="#E53935" stroke-width="1"
        class="wexpert-process-path-flow-slow" />

      <!-- Diagonal accent lines -->
      <line x1="0" y1="0" x2="400" y2="900" stroke="#E2E8F0" stroke-width="0.8" />
      <line x1="0" y1="0" x2="400" y2="900" stroke="#E53935" stroke-width="1" class="wexpert-process-path-flow" />

      <line x1="1440" y1="0" x2="1040" y2="900" stroke="#E2E8F0" stroke-width="0.8" />
      <line x1="1440" y1="0" x2="1040" y2="900" stroke="#2563EB" stroke-width="1"
        class="wexpert-process-path-flow-reverse" />

      <!-- Intersection dots — pulse -->
      <circle class="wexpert-process-dot-pulse" cx="200" cy="120" r="4" fill="#E53935" />
      <circle class="wexpert-process-dot-pulse" cx="500" cy="300" r="4" fill="#2563EB" />
      <circle class="wexpert-process-dot-pulse" cx="900" cy="480" r="4" fill="#16A34A" />
      <circle class="wexpert-process-dot-pulse" cx="1200" cy="660" r="4" fill="#E53935" />
      <circle class="wexpert-process-dot-pulse" cx="200" cy="820" r="4" fill="#2563EB" />

      <!-- Corner decorative circles -->
      <circle cx="1380" cy="60" r="40" fill="none" stroke="#E2E8F0" stroke-width="1" />
      <circle cx="1380" cy="60" r="40" fill="none" stroke="#E53935" stroke-width="1"
        class="wexpert-process-path-flow-slow" />

      <circle cx="60" cy="840" r="30" fill="none" stroke="#E2E8F0" stroke-width="1" />
      <circle cx="60" cy="840" r="30" fill="none" stroke="#2563EB" stroke-width="1" class="wexpert-process-path-flow" />

      <circle cx="720" cy="450" r="60" fill="none" stroke="#E2E8F0" stroke-width="0.8" />
      <circle cx="720" cy="450" r="60" fill="none" stroke="#16A34A" stroke-width="0.8"
        class="wexpert-process-path-flow-reverse" />

      <!-- Small decorative dots scattered -->
      <circle cx="100" cy="200" r="2.5" fill="#CBD5E1" opacity="0.6" />
      <circle cx="350" cy="450" r="2.5" fill="#CBD5E1" opacity="0.6" />
      <circle cx="750" cy="150" r="2.5" fill="#CBD5E1" opacity="0.6" />
      <circle cx="1100" cy="350" r="2.5" fill="#CBD5E1" opacity="0.6" />
      <circle cx="1350" cy="700" r="2.5" fill="#CBD5E1" opacity="0.6" />
      <circle cx="650" cy="750" r="2.5" fill="#CBD5E1" opacity="0.6" />
      <circle cx="950" cy="600" r="2.5" fill="#CBD5E1" opacity="0.6" />
      <circle cx="300" cy="680" r="2.5" fill="#CBD5E1" opacity="0.6" />

    </svg>
    <div class="container">

      <!-- Header -->
      <div class="wexpert-process-header" data-aos="fade-up">
        <div class="section-label mx-auto"><i class="bi bi-map-fill"></i> How We Work</div>
        <h2 class="section-title">How we take your project<br>from <span class="accent"> brief to live</span></h2>
      </div>

      <!-- Timeline -->
      <div class="wexpert-process-timeline">

        <!-- Step 1 -->
        <div class="wexpert-process-step" data-aos="fade-right-off">
          <div class="wexpert-process-card">
            <div class="wexpert-process-card-tag"><i class="bi bi-chat-dots-fill"></i> Step 01</div>
            <div class="wexpert-process-card-title">Understanding Your Needs</div>
            <p class="wexpert-process-card-desc">We start by learning about your business, goals, and target audience.
            </p>
          </div>
          <div class="wexpert-process-bubble-wrap">
            <div class="wexpert-process-bubble">1</div>
          </div>
          <div class="flex-1 d-none d-md-block"></div>
        </div>

        <!-- Step 2 -->
        <div class="wexpert-process-step" data-aos="fade-left-off">
          <div class="wexpert-process-card">
            <div class="wexpert-process-card-tag"><i class="bi bi-clipboard-data-fill"></i> Step 02</div>
            <div class="wexpert-process-card-title">Planning & Strategy</div>
            <p class="wexpert-process-card-desc">We create a clear plan for design, structure, and functionality.</p>
          </div>
          <div class="wexpert-process-bubble-wrap">
            <div class="wexpert-process-bubble">2</div>
          </div>
          <div class="flex-1 d-none d-md-block"></div>
        </div>

        <!-- Step 3 -->
        <div class="wexpert-process-step" data-aos="fade-right-off">
          <div class="wexpert-process-card">
            <div class="wexpert-process-card-tag"><i class="bi bi-brush-fill"></i> Step 03</div>
            <div class="wexpert-process-card-title">Design & Development</div>
            <p class="wexpert-process-card-desc">Our team designs modern UI/UX and develops a fast, responsive website.
            </p>
          </div>
          <div class="wexpert-process-bubble-wrap">
            <div class="wexpert-process-bubble">3</div>
          </div>
          <div class="flex-1 d-none d-md-block"></div>
        </div>

        <!-- Step 4 -->
        <div class="wexpert-process-step" data-aos="fade-left-off">
          <div class="wexpert-process-card">
            <div class="wexpert-process-card-tag"><i class="bi bi-speedometer2"></i> Step 04</div>
            <div class="wexpert-process-card-title">Testing & Optimization</div>
            <p class="wexpert-process-card-desc">We test across all devices and optimize for speed, SEO, and
              performance.</p>
          </div>
          <div class="wexpert-process-bubble-wrap">
            <div class="wexpert-process-bubble">4</div>
          </div>
          <div class="flex-1 d-none d-md-block"></div>
        </div>

        <!-- Step 5 -->
        <div class="wexpert-process-step" data-aos="fade-right-off">
          <div class="wexpert-process-card">
            <div class="wexpert-process-card-tag"><i class="bi bi-rocket-takeoff-fill"></i> Step 05</div>
            <div class="wexpert-process-card-title">Launch & Support</div>
            <p class="wexpert-process-card-desc">We launch your website and provide ongoing support if needed.</p>
          </div>
          <div class="wexpert-process-bubble-wrap">
            <div class="wexpert-process-bubble">5</div>
          </div>
          <div class="flex-1 d-none d-md-block"></div>
        </div>

      </div>
    </div>
  </section>



  <!-- ══════ WHY CHOOSE US ══════ -->
  <!-- <section class="section" id="about" style="background:var(--subtle);border-top:1px solid var(--border)">
    <div class="container">
      <div class="row g-5 align-items-center">
        <div class="col-lg-6" data-aos="fade-right-off">
          <div class="section-label"><i class="bi bi-patch-check-fill"></i> Why Web EASY Experts</div>
          <h2 class="section-title">India's talent. Your business. Real results.</h2>
          <p class="section-sub" style="max-width:100%">Web EASY Experts is a dedicated team of skilled website
            designers and developers based in India, delivering high-quality web solutions to businesses worldwide since
            2023. We develop custom designs; performance-driven websites that help businesses attract the right audience
            and convert visitors into customers.</p>
          <div class="d-flex flex-wrap gap-3 mt-4">
            <a href="#contact" class="btn btn-brand">Talk to Our Team <i class="bi bi-arrow-right ms-1"></i></a>
            <a href="#" class="btn btn-outline-soft">Our Story</a>
          </div>
        </div>
        <div class="col-lg-6" data-aos="fade-left-off">
          <div class="why-item">
            <div class="why-icon" style="background:#FEE2E2;color:var(--red)"><i class="bi bi-people-fill"></i></div>
            <div>
              <div style="font-family:var(--display);font-weight:700;color:var(--t900);margin-bottom:.25rem">Experienced
                & Skilled Team</div>
              <div style="font-size:.875rem;color:var(--t500)">Unlike traditional agencies, we work as a flexible team
                of web experts, allowing us to keep costs low while maintaining high standards.</div>
            </div>
          </div>
          <div class="why-item">
            <div class="why-icon" style="background:#F0FDF4;color:#16A34A"><i class="bi bi-patch-check-fill"></i></div>
            <div>
              <div style="font-family:var(--display);font-weight:700;color:var(--t900);margin-bottom:.25rem">100%
                Customer Satisfaction</div>
              <div style="font-size:.875rem;color:var(--t500)">We understand your business, analyse your audience, and
                build websites that support long-term growth — until you're completely satisfied.</div>
            </div>
          </div>
          <div class="why-item">
            <div class="why-icon" style="background:#EFF6FF;color:#2563EB"><i class="bi bi-clock-fill"></i></div>
            <div>
              <div style="font-family:var(--display);font-weight:700;color:var(--t900);margin-bottom:.25rem">On-Time
                Project Delivery</div>
              <div style="font-size:.875rem;color:var(--t500)">Our process is simple and efficient — we plan, design,
                develop, and deliver on schedule, every time.</div>
            </div>
          </div>
          <div class="why-item">
            <div class="why-icon" style="background:#FFF7ED;color:#EA580C"><i class="bi bi-currency-dollar"></i></div>
            <div>
              <div style="font-family:var(--display);font-weight:700;color:var(--t900);margin-bottom:.25rem">Transparent
                Pricing</div>
              <div style="font-size:.875rem;color:var(--t500)">No hidden costs, no unnecessary complexity. Just a clear
                process focused on delivering real business growth.</div>
            </div>
          </div>
          <div class="why-item">
            <div class="why-icon" style="background:#F0FDFA;color:#0D9488"><i class="bi bi-shield-check"></i></div>
            <div>
              <div style="font-family:var(--display);font-weight:700;color:var(--t900);margin-bottom:.25rem">Secure &
                Reliable Websites</div>
              <div style="font-size:.875rem;color:var(--t500)">We build fast, user-friendly, and SEO-ready websites with
                security built in from day one — keeping your business safe online.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->

  <!-- ══════ WHY CHOOSE — 8 Points ══════ -->
  <section class="wexpert-whychoose-section" id="why-choose">
    <div class="wexpert-whychoose-gridbg"></div>
    <div class="wexpert-whychoose-blob"></div>
    <div class="container">

      <!-- Header -->
      <div class="wexpert-whychoose-header" data-aos="fade-up">
        <div class="wexpert-whychoose-badge">
          <i class="bi bi-patch-check-fill"></i> Why Choose Us
        </div>
        <h2 class="wexpert-whychoose-heading">Why Choose <span>Web EASY Experts</span><br>for Web Design & Development
        </h2>
      </div>

      <!-- 8 Rows — 2 per row -->
      <div class="wexpert-whychoose-grid" data-aos="fade-up">

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">Affordable Without Compromise</div>
            <p class="wexpert-whychoose-row-desc">We deliver high-quality, low-cost web design solutions—giving you a
              professional website without expensive agency pricing.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">Custom & Conversion-Focused Design</div>
            <p class="wexpert-whychoose-row-desc">Every website is tailored to your business goals and audience,
              designed not just to look good but to generate leads and drive results.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">Dynamic & Easy to Manage</div>
            <p class="wexpert-whychoose-row-desc">Our websites are dynamic and user-friendly, allowing you to easily
              update content, add pages, and scale as your business grows.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">Fully Mobile-Responsive</div>
            <p class="wexpert-whychoose-row-desc">Your website will work flawlessly across mobile, tablet, and
              desktop—ensuring a seamless experience for every visitor.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">SEO-Ready & Fast Loading</div>
            <p class="wexpert-whychoose-row-desc">We build websites with SEO best practices and optimised speed, helping
              you rank better and keep users engaged.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">AI-Ready & Future-Friendly</div>
            <p class="wexpert-whychoose-row-desc">Our websites are built to integrate with modern tools like AI
              chatbots, automation, and smart technologies—keeping you ahead of the curve.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">Direct Communication & Reliable Support</div>
            <p class="wexpert-whychoose-row-desc">Work directly with our expert team—no middlemen, no confusion, just
              clear communication and ongoing support when you need it.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

        <div class="wexpert-whychoose-row">
          <div class="wexpert-whychoose-check"><i class="bi bi-check-circle-fill"></i></div>
          <div class="wexpert-whychoose-row-text">
            <div class="wexpert-whychoose-row-title">Simple. Transparent. Effective.</div>
            <p class="wexpert-whychoose-row-desc">No hidden costs, no unnecessary complexity. Just a clear process
              focused on delivering real business growth.</p>
          </div>
          <i class="bi bi-arrow-right wexpert-whychoose-row-arrow"></i>
        </div>

      </div>
    </div>
  </section>

  <!-- ══════ STATS ══════ -->
  <section class="stats-section">
    <div class="container">
      <div class="row g-4 text-center">
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="0">
          <div class="stat-number"><span class="counter" data-target="500">0</span><span class="unit">+</span></div>
          <div class="stat-label">Projects Delivered</div>
        </div>
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="80">
          <div class="stat-number"><span class="counter" data-target="10">0</span><span class="unit">+</span></div>
          <div class="stat-label">Years of Experience</div>
        </div>
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="160">
          <div class="stat-number"><span class="counter" data-target="98">0</span><span class="unit">%</span></div>
          <div class="stat-label">Satisfaction Rate</div>
        </div>
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="240">
          <div class="stat-number"><span class="counter" data-target="15">0</span><span class="unit">+</span></div>
          <div class="stat-label">Countries Served</div>
        </div>
      </div>
    </div>
  </section>

  <!-- testimonial -->
  <section class="wexpert-testi-section" id="testimonials">
    <div class="wexpert-testi-gridbg"></div>
    <div class="wexpert-testi-fade-top"></div>
    <div class="wexpert-testi-fade-bottom"></div>
    <div class="container">

      <!-- Header -->
      <div class="wexpert-testi-header" data-aos="fade-up">
        <div class="wexpert-testi-badge"><i class="bi bi-chat-quote-fill"></i> Client Stories</div>
        <h2 class="wexpert-testi-heading">Trusted by Clients <span class="accent-red">Worldwide</span> </h2>
      </div>

      <!-- 4 Column Scroll -->
      <div class="wexpert-testi-wrapper">

        <!-- COL 1 — UP -->
        <div class="wexpert-testi-col wexpert-testi-col--up">

          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Web EASY Experts delivered exactly what we needed. The website is fast,
              modern, and works perfectly on all devices."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">TB</div>
              <div>
                <div class="wexpert-testi-name">Thiago Bernardez</div>
                <div class="wexpert-testi-role">Business Owner, Sydney</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Our Google Ads ROAS went from 1.8x to 4.6x in just 60 days. The team
              really knows digital marketing."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">MK</div>
              <div>
                <div class="wexpert-testi-name">Marcus Klein</div>
                <div class="wexpert-testi-role">eCommerce Owner, Germany</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"They redesigned our website and our bounce rate dropped by 40%. Incredible
              results in such a short time."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">SP</div>
              <div>
                <div class="wexpert-testi-name">Sophie Palmer</div>
                <div class="wexpert-testi-role">Marketing Director, London</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"SEO results were visible within 6 weeks. We went from page 4 to page 1 for
              our main keywords."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">RN</div>
              <div>
                <div class="wexpert-testi-name">Raj Nair</div>
                <div class="wexpert-testi-role">Startup Founder, Singapore</div>
              </div>
            </div>
          </div>

          <!-- Duplicate for infinite loop -->
          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Web EASY Experts delivered exactly what we needed. The website is fast,
              modern, and works perfectly on all devices."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">TB</div>
              <div>
                <div class="wexpert-testi-name">Thiago Bernardez</div>
                <div class="wexpert-testi-role">Business Owner, Sydney</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Our Google Ads ROAS went from 1.8x to 4.6x in just 60 days. The team
              really knows digital marketing."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">MK</div>
              <div>
                <div class="wexpert-testi-name">Marcus Klein</div>
                <div class="wexpert-testi-role">eCommerce Owner, Germany</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"They redesigned our website and our bounce rate dropped by 40%. Incredible
              results in such a short time."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">SP</div>
              <div>
                <div class="wexpert-testi-name">Sophie Palmer</div>
                <div class="wexpert-testi-role">Marketing Director, London</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"SEO results were visible within 6 weeks. We went from page 4 to page 1 for
              our main keywords."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">RN</div>
              <div>
                <div class="wexpert-testi-name">Raj Nair</div>
                <div class="wexpert-testi-role">Startup Founder, Singapore</div>
              </div>
            </div>
          </div>

        </div>

        <!-- COL 2 — DOWN -->
        <div class="wexpert-testi-col wexpert-testi-col--down">

          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"They understood our business and created a custom website that helped us
              attract more customers."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">AF</div>
              <div>
                <div class="wexpert-testi-name">Angus Fraser</div>
                <div class="wexpert-testi-role">Director, Melbourne</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Our Meta Ads campaign hit a 3.2x ROAS in the first month. The creatives
              and targeting were spot on."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">LB</div>
              <div>
                <div class="wexpert-testi-name">Laura Bennett</div>
                <div class="wexpert-testi-role">Brand Manager, Canada</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"The Shopify store they built for us loads in under 2 seconds and our
              conversion rate improved by 28%."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">JT</div>
              <div>
                <div class="wexpert-testi-name">James Turner</div>
                <div class="wexpert-testi-role">eCommerce Founder, USA</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Best value for money. The website quality is on par with what agencies
              charge 5x more for."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">NV</div>
              <div>
                <div class="wexpert-testi-name">Nina Verhoeven</div>
                <div class="wexpert-testi-role">Entrepreneur, Netherlands</div>
              </div>
            </div>
          </div>

          <!-- Duplicate -->
          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"They understood our business and created a custom website that helped us
              attract more customers."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">AF</div>
              <div>
                <div class="wexpert-testi-name">Angus Fraser</div>
                <div class="wexpert-testi-role">Director, Melbourne</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Our Meta Ads campaign hit a 3.2x ROAS in the first month. The creatives
              and targeting were spot on."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">LB</div>
              <div>
                <div class="wexpert-testi-name">Laura Bennett</div>
                <div class="wexpert-testi-role">Brand Manager, Canada</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"The Shopify store they built for us loads in under 2 seconds and our
              conversion rate improved by 28%."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">JT</div>
              <div>
                <div class="wexpert-testi-name">James Turner</div>
                <div class="wexpert-testi-role">eCommerce Founder, USA</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Best value for money. The website quality is on par with what agencies
              charge 5x more for."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">NV</div>
              <div>
                <div class="wexpert-testi-name">Nina Verhoeven</div>
                <div class="wexpert-testi-role">Entrepreneur, Netherlands</div>
              </div>
            </div>
          </div>

        </div>

        <!-- COL 3 — UP SLOW -->
        <div class="wexpert-testi-col wexpert-testi-col--up-slow">

          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Professional team, clear communication, and great results. Highly
              recommended for global projects."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">SM</div>
              <div>
                <div class="wexpert-testi-name">Sarah Mitchell</div>
                <div class="wexpert-testi-role">Founder, Brisbane</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"We saw a 55% increase in organic traffic within 3 months of launching the
              new SEO strategy."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">DH</div>
              <div>
                <div class="wexpert-testi-name">Daniel Hughes</div>
                <div class="wexpert-testi-role">CEO, Dublin Ireland</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"The landing page they designed doubled our lead conversion rate.
              Exceptional attention to detail."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">AW</div>
              <div>
                <div class="wexpert-testi-name">Aisha Williams</div>
                <div class="wexpert-testi-role">Marketing Head, UAE</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Transparent pricing, no surprises. They delivered the full project on time
              and within budget."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">PL</div>
              <div>
                <div class="wexpert-testi-name">Peter Larsson</div>
                <div class="wexpert-testi-role">Business Owner, Sweden</div>
              </div>
            </div>
          </div>

          <!-- Duplicate -->
          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Professional team, clear communication, and great results. Highly
              recommended for global projects."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">SM</div>
              <div>
                <div class="wexpert-testi-name">Sarah Mitchell</div>
                <div class="wexpert-testi-role">Founder, Brisbane</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"We saw a 55% increase in organic traffic within 3 months of launching the
              new SEO strategy."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">DH</div>
              <div>
                <div class="wexpert-testi-name">Daniel Hughes</div>
                <div class="wexpert-testi-role">CEO, Dublin Ireland</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"The landing page they designed doubled our lead conversion rate.
              Exceptional attention to detail."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">AW</div>
              <div>
                <div class="wexpert-testi-name">Aisha Williams</div>
                <div class="wexpert-testi-role">Marketing Head, UAE</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Transparent pricing, no surprises. They delivered the full project on time
              and within budget."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">PL</div>
              <div>
                <div class="wexpert-testi-name">Peter Larsson</div>
                <div class="wexpert-testi-role">Business Owner, Sweden</div>
              </div>
            </div>
          </div>

        </div>

        <!-- COL 4 — DOWN SLOW -->
        <div class="wexpert-testi-col wexpert-testi-col--down-slow">

          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Switched from a local agency and the difference is night and day. Better
              quality, faster delivery, half the price."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">RK</div>
              <div>
                <div class="wexpert-testi-name">Ravi Kumar</div>
                <div class="wexpert-testi-role">SME Owner, Dubai UAE</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Their WordPress site is lightning fast and the SEO structure they built
              helped us rank in 3 countries."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">CO</div>
              <div>
                <div class="wexpert-testi-name">Claire O'Brien</div>
                <div class="wexpert-testi-role">Agency Director, Ireland</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Our Google rankings improved significantly within 3 months. The SEO-ready
              structure made all the difference."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">ND</div>
              <div>
                <div class="wexpert-testi-name">Nina Davies</div>
                <div class="wexpert-testi-role">Marketing Manager, London</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Communication was seamless despite the time difference. They treated our
              project with full dedication."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">TS</div>
              <div>
                <div class="wexpert-testi-name">Thomas Schmidt</div>
                <div class="wexpert-testi-role">Founder, Berlin Germany</div>
              </div>
            </div>
          </div>

          <!-- Duplicate -->
          <div class="wexpert-testi-card c-blue">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Switched from a local agency and the difference is night and day. Better
              quality, faster delivery, half the price."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-blue">RK</div>
              <div>
                <div class="wexpert-testi-name">Ravi Kumar</div>
                <div class="wexpert-testi-role">SME Owner, Dubai UAE</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-yellow">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Their WordPress site is lightning fast and the SEO structure they built
              helped us rank in 3 countries."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-yellow">CO</div>
              <div>
                <div class="wexpert-testi-name">Claire O'Brien</div>
                <div class="wexpert-testi-role">Agency Director, Ireland</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-green">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Our Google rankings improved significantly within 3 months. The SEO-ready
              structure made all the difference."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-green">ND</div>
              <div>
                <div class="wexpert-testi-name">Nina Davies</div>
                <div class="wexpert-testi-role">Marketing Manager, London</div>
              </div>
            </div>
          </div>

          <div class="wexpert-testi-card c-red">
            <div class="wexpert-testi-stars">★★★★★</div>
            <div class="wexpert-testi-quote">"Communication was seamless despite the time difference. They treated our
              project with full dedication."</div>
            <div class="wexpert-testi-author">
              <div class="wexpert-testi-av c-red">TS</div>
              <div>
                <div class="wexpert-testi-name">Thomas Schmidt</div>
                <div class="wexpert-testi-role">Founder, Berlin Germany</div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  </section>



  <!-- ══════ COMPARISON TABLE ══════ -->
  <section class="section compare-section" id="compare">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <div class="section-label mx-auto">
          <i class="bi bi-trophy-fill"></i> Our Advantages
        </div>

        <h2 class="section-title">Everything You Need to <span class="accent"> Grow Online</span></h2>

        <p class="section-sub mx-auto">
          We provide all essential tools, support, and expertise to help your business succeed online.
        </p>
      </div>

      <p class="scroll-hint">
        <i class="bi bi-arrow-left-right me-1"></i> Explore Features
      </p>

      <div class="compare-wrap" data-aos="fade-up">
        <table class="compare-table">
          <thead>
            <tr>
              <th>Feature</th>

              <th class="us-col">
                <i class="bi bi-grid-3x3-gap-fill me-1"></i> Web EASY Experts
                <span class="us-col-badge">
                  <i class="bi bi-award-fill"></i> Included
                </span>
              </th>

              <th>Business Value</th>
              <th>Performance</th>
              <th>Support</th>
            </tr>
          </thead>

          <tbody>

            <tr>
              <td>Professional & Clean Design</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Brand Focused</span></td>
              <td><span class="ct-text">Modern Layout</span></td>
              <td><span class="ct-text">Flexible Updates</span></td>
            </tr>

            <tr>
              <td>Mobile-First & Fully Responsive</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Better Reach</span></td>
              <td><span class="ct-text">All Devices Ready</span></td>
              <td><span class="ct-text">Continuous Testing</span></td>
            </tr>

            <tr>
              <td>SEO-Ready from Day One</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Higher Visibility</span></td>
              <td><span class="ct-text">Optimized Structure</span></td>
              <td><span class="ct-text">Basic SEO Guidance</span></td>
            </tr>

            <tr>
              <td>Fast Page Load Speed (Core Web Vitals)</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Better UX</span></td>
              <td><span class="ct-text">High Speed</span></td>
              <td><span class="ct-text">Performance Monitoring</span></td>
            </tr>

            <tr>
              <td>Dedicated Project Manager</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Clear Communication</span></td>
              <td><span class="ct-text">Smooth Workflow</span></td>
              <td><span class="ct-text">Direct Support</span></td>
            </tr>

            <tr>
              <td>Post-Launch Support Included</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Business Continuity</span></td>
              <td><span class="ct-text">Quick Fixes</span></td>
              <td><span class="ct-text">Ongoing Help</span></td>
            </tr>

            <tr>
              <td>eCommerce & Custom Integrations</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Scalable Growth</span></td>
              <td><span class="ct-text">Advanced Features</span></td>
              <td><span class="ct-text">Integration Support</span></td>
            </tr>

            <tr>
              <td>100% Satisfaction Guarantee</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Risk-Free</span></td>
              <td><span class="ct-text">Quality Assurance</span></td>
              <td><span class="ct-text">Client Priority</span></td>
            </tr>

            <tr>
              <td>Fixed Price (No Hidden Charges)</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Transparent</span></td>
              <td><span class="ct-text">No Surprises</span></td>
              <td><span class="ct-text">Clear Scope</span></td>
            </tr>

            <tr>
              <td>WhatsApp / Direct Communication</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Easy Reach</span></td>
              <td><span class="ct-text">Fast Response</span></td>
              <td><span class="ct-text">Always Available</span></td>
            </tr>

            <tr>
              <td>Delivery Approach</td>
              <td class="us-col">
                <span class="ct-text highlight">Quality-First Delivery</span>
              </td>
              <td><span class="ct-text">Carefully Planned</span></td>
              <td><span class="ct-text">Optimized Process</span></td>
              <td><span class="ct-text">Consistent Updates</span></td>
            </tr>

            <!-- REPLACED PRICE ROW -->
            <tr>
              <td>Long-Term Business Growth</td>
              <td class="us-col"><span class="ct-yes"><i class="bi bi-check-lg"></i></span></td>
              <td><span class="ct-text">Scalable Strategy</span></td>
              <td><span class="ct-text">Future Ready</span></td>
              <td><span class="ct-text">Continuous Support</span></td>
            </tr>

          </tbody>

          <tfoot>
            <tr>
              <td>
                <i class="bi bi-info-circle me-1"></i>
                All features included with no hidden conditions
              </td>

              <td class="us-col">
                <a href="#contact" class="btn-brand btn" style="font-size:0.78rem;padding:0.4rem 1rem">
                  Get Started <i class="bi bi-arrow-right ms-1"></i>
                </a>
              </td>

              <td></td>
              <td></td>
              <td></td>
            </tr>
          </tfoot>

        </table>
      </div>

      <!-- Bottom trust note -->
      <div class="text-center mt-4" data-aos="fade-up">
        <p style="font-size:0.82rem;color:var(--t500)">
          <i class="bi bi-shield-check text-success me-1"></i>
          No upfront payment &nbsp;·&nbsp;

          <i class="bi bi-star-fill text-warning me-1"></i>
          Quality Focused Work &nbsp;·&nbsp;

          <i class="bi bi-people-fill text-danger me-1"></i>
          Built for Growing Businesses
        </p>
      </div>

    </div>
  </section>

  <!-- ══════ PORTFOLIO ══════ -->
  <!-- <section class="section" id="portfolio" style="background:var(--bg)">
    <div class="container">
      <div class="text-center mb-4" data-aos="fade-up">
        <div class="section-label mx-auto"><i class="bi bi-images"></i> Our Work</div>
        <h2 class="section-title">500+ projects. Each one a story.</h2>
        <p class="section-sub mx-auto">We don't just deliver projects — we deliver results. Here's a taste of what we've
          built.</p>
      </div>
      <div class="filter-wrap" data-aos="fade-up">
        <button class="filter-btn active" data-filter="all">All</button>
        <button class="filter-btn" data-filter="web">Websites</button>
        <button class="filter-btn" data-filter="logo">Logo & Branding</button>
        <button class="filter-btn" data-filter="seo">SEO</button>
        <button class="filter-btn" data-filter="ecom">E-Commerce</button>
      </div>
      <div class="row g-4" id="portfolioGrid">
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0" data-cat="web">
          <div class="port-card">
            <div class="port-thumb" style="background:linear-gradient(135deg,#1E3A5F,#2563EB)"><i
                class="bi bi-building pt-icon"></i></div>
            <div class="port-overlay"><a href="#" class="btn"
                style="background:rgba(255,255,255,0.15);color:#fff;border:1px solid rgba(255,255,255,0.3);border-radius:10px;font-size:0.82rem;padding:0.45rem 1rem">View
                Project <i class="bi bi-arrow-up-right ms-1"></i></a></div>
            <div class="port-body">
              <div class="port-cat">Website Design</div>
              <div class="port-title">Sharma Realty — Premium Real Estate Website</div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="60" data-cat="logo">
          <div class="port-card">
            <div class="port-thumb" style="background:linear-gradient(135deg,#7C3AED,#C084FC)"><i
                class="bi bi-vector-pen pt-icon"></i></div>
            <div class="port-overlay"><a href="#" class="btn"
                style="background:rgba(255,255,255,0.15);color:#fff;border:1px solid rgba(255,255,255,0.3);border-radius:10px;font-size:0.82rem;padding:0.45rem 1rem">View
                Project <i class="bi bi-arrow-up-right ms-1"></i></a></div>
            <div class="port-body">
              <div class="port-cat">Logo & Branding</div>
              <div class="port-title">Zehni Jewels — Complete Brand Identity System</div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="120" data-cat="seo">
          <div class="port-card">
            <div class="port-thumb" style="background:linear-gradient(135deg,#064E3B,#16A34A)"><i
                class="bi bi-graph-up-arrow pt-icon"></i></div>
            <div class="port-overlay"><a href="#" class="btn"
                style="background:rgba(255,255,255,0.15);color:#fff;border:1px solid rgba(255,255,255,0.3);border-radius:10px;font-size:0.82rem;padding:0.45rem 1rem">View
                Project <i class="bi bi-arrow-up-right ms-1"></i></a></div>
            <div class="port-body">
              <div class="port-cat">SEO Campaign</div>
              <div class="port-title">Mehta Clinics — 3x Organic Traffic in 90 Days</div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0" data-cat="ecom">
          <div class="port-card">
            <div class="port-thumb" style="background:linear-gradient(135deg,#92400E,#F59E0B)"><i
                class="bi bi-bag-fill pt-icon"></i></div>
            <div class="port-overlay"><a href="#" class="btn"
                style="background:rgba(255,255,255,0.15);color:#fff;border:1px solid rgba(255,255,255,0.3);border-radius:10px;font-size:0.82rem;padding:0.45rem 1rem">View
                Project <i class="bi bi-arrow-up-right ms-1"></i></a></div>
            <div class="port-body">
              <div class="port-cat">E-Commerce</div>
              <div class="port-title">TrendKart — Fashion Store, ₹50L+ Monthly Revenue</div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="60" data-cat="web">
          <div class="port-card">
            <div class="port-thumb" style="background:linear-gradient(135deg,#1E293B,#334155)"><i
                class="bi bi-cpu-fill pt-icon"></i></div>
            <div class="port-overlay"><a href="#" class="btn"
                style="background:rgba(255,255,255,0.15);color:#fff;border:1px solid rgba(255,255,255,0.3);border-radius:10px;font-size:0.82rem;padding:0.45rem 1rem">View
                Project <i class="bi bi-arrow-up-right ms-1"></i></a></div>
            <div class="port-body">
              <div class="port-cat">Website + App</div>
              <div class="port-title">SwiftLogix — Logistics Management Portal</div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="120" data-cat="logo">
          <div class="port-card">
            <div class="port-thumb" style="background:linear-gradient(135deg,#BE185D,#F472B6)"><i
                class="bi bi-palette-fill pt-icon"></i></div>
            <div class="port-overlay"><a href="#" class="btn"
                style="background:rgba(255,255,255,0.15);color:#fff;border:1px solid rgba(255,255,255,0.3);border-radius:10px;font-size:0.82rem;padding:0.45rem 1rem">View
                Project <i class="bi bi-arrow-up-right ms-1"></i></a></div>
            <div class="port-body">
              <div class="port-cat">Brand Identity</div>
              <div class="port-title">Chai &amp; Co. — Café Rebrand with Full Brand Kit</div>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center mt-5" data-aos="fade-up"><a href="#" class="btn-outline-soft btn px-5">View All 500+
          Projects <i class="bi bi-arrow-right ms-2"></i></a></div>
    </div>
  </section> -->

  <!-- ══════ PROCESS ══════ -->
  <!-- <section class="section" id="process" style="background:var(--subtle);border-top:1px solid var(--border)">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <div class="section-label mx-auto"><i class="bi bi-map-fill"></i> Our Process</div>
        <h2 class="section-title">How we take your project<br>from brief to live.</h2>
      </div>
      <div class="d-flex flex-wrap gap-2 justify-content-center mb-4" data-aos="fade-up">
        <button class="proc-tab active" data-proc="web"><i class="bi bi-laptop"></i> Web Design</button>
        <button class="proc-tab" data-proc="seo"><i class="bi bi-search"></i> SEO</button>
        <button class="proc-tab" data-proc="ads"><i class="bi bi-megaphone-fill"></i> Paid Ads</button>
        <button class="proc-tab" data-proc="logo"><i class="bi bi-vector-pen"></i> Branding</button>
      </div>
      <div class="proc-panel active" id="proc-web" data-aos="fade-up">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">1</div>
              <div><strong>Discovery & Brief</strong><br><span style="font-size:.875rem;color:var(--t500)">We deep-dive
                  into your business goals, target audience, and competitors. No templates, everything custom.</span>
              </div>
            </div>
            <div class="proc-step">
              <div class="proc-num">2</div>
              <div><strong>Wireframe & Prototype</strong><br><span style="font-size:.875rem;color:var(--t500)">We sketch
                  the full user journey before writing a single line of code. You approve every screen.</span></div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">3</div>
              <div><strong>Design & Development</strong><br><span
                  style="font-size:.875rem;color:var(--t500)">Pixel-perfect design brought to life with clean, fast
                  code. Mobile-first, SEO-ready from day one.</span></div>
            </div>
            <div class="proc-step">
              <div class="proc-num">4</div>
              <div><strong>Launch & Handover</strong><br><span style="font-size:.875rem;color:var(--t500)">We test on
                  20+ devices, then launch. Training session included, 30-day support post-launch.</span></div>
            </div>
          </div>
        </div>
      </div>
      <div class="proc-panel" id="proc-seo">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">1</div>
              <div><strong>Full SEO Audit</strong><br><span style="font-size:.875rem;color:var(--t500)">Technical health
                  check, keyword gap analysis, backlink profile, competitor benchmarking.</span></div>
            </div>
            <div class="proc-step">
              <div class="proc-num">2</div>
              <div><strong>Keyword Strategy</strong><br><span style="font-size:.875rem;color:var(--t500)">We identify
                  high-intent, low-competition keywords — both English and Hindi terms for your niche.</span></div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">3</div>
              <div><strong>On-Page + Content</strong><br><span style="font-size:.875rem;color:var(--t500)">Meta tags,
                  schema, page speed, plus SEO-optimised blogs and landing pages every month.</span></div>
            </div>
            <div class="proc-step">
              <div class="proc-num">4</div>
              <div><strong>Link Building & Reporting</strong><br><span
                  style="font-size:.875rem;color:var(--t500)">High-DA backlink campaigns, monthly rank tracking reports
                  in plain English.</span></div>
            </div>
          </div>
        </div>
      </div>
      <div class="proc-panel" id="proc-ads">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">1</div>
              <div><strong>Goal & Budget Planning</strong><br><span style="font-size:.875rem;color:var(--t500)">We
                  define CPL targets, ROAS goals, and allocate budgets across Google, Meta, and YouTube.</span></div>
            </div>
            <div class="proc-step">
              <div class="proc-num">2</div>
              <div><strong>Creative & Copy</strong><br><span style="font-size:.875rem;color:var(--t500)">Ad visuals and
                  copies crafted in-house — no generic stock imagery, no bland headlines.</span></div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">3</div>
              <div><strong>Campaign Launch & A/B Test</strong><br><span
                  style="font-size:.875rem;color:var(--t500)">Multiple ad variants running simultaneously so the best
                  one always wins more budget.</span></div>
            </div>
            <div class="proc-step">
              <div class="proc-num">4</div>
              <div><strong>Optimise & Scale</strong><br><span style="font-size:.875rem;color:var(--t500)">Weekly
                  optimisation rounds, bi-weekly calls, monthly ROI breakdown reports.</span></div>
            </div>
          </div>
        </div>
      </div>
      <div class="proc-panel" id="proc-logo">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">1</div>
              <div><strong>Brand Discovery Call</strong><br><span style="font-size:.875rem;color:var(--t500)">We
                  understand your values, target customers, and what you want your brand to feel like.</span></div>
            </div>
            <div class="proc-step">
              <div class="proc-num">2</div>
              <div><strong>Moodboard & Direction</strong><br><span style="font-size:.875rem;color:var(--t500)">3
                  distinct visual directions presented. You pick the one that resonates, we refine from there.</span>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="proc-step">
              <div class="proc-num">3</div>
              <div><strong>Logo & Brand Kit Design</strong><br><span style="font-size:.875rem;color:var(--t500)">Logos
                  in all formats, colour system, typography guide, icon set, social templates.</span></div>
            </div>
            <div class="proc-step">
              <div class="proc-num">4</div>
              <div><strong>Delivery & Brand Manual</strong><br><span style="font-size:.875rem;color:var(--t500)">All
                  source files + a brand guideline PDF so any future designer can maintain consistency.</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> -->

  <!-- ══════ AWARDS ══════ -->
  <!-- <section class="awards-section">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <div class="section-label mx-auto" style="background:rgba(255,255,255,.1);color:rgba(255,255,255,.85)"><i
            class="bi bi-trophy-fill"></i> Awards</div>
        <h2 class="section-title" style="color:#fff">Recognised by the industry.<br>Loved by our clients.</h2>
      </div>
      <div class="row g-4">
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="0">
          <div class="award-card">
            <div class="award-icon"><i class="bi bi-award-fill"></i></div>
            <div class="award-title">Best Digital Agency</div>
            <div class="award-org">DIGIXX India 2024</div>
          </div>
        </div>
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="80">
          <div class="award-card">
            <div class="award-icon"><i class="bi bi-google"></i></div>
            <div class="award-title">Google Premier Partner</div>
            <div class="award-org">Google Ads 2023–2026</div>
          </div>
        </div>
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="160">
          <div class="award-card">
            <div class="award-icon"><i class="bi bi-star-fill"></i></div>
            <div class="award-title">Top Rated Agency</div>
            <div class="award-org">Clutch.co — India 2024</div>
          </div>
        </div>
        <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="240">
          <div class="award-card">
            <div class="award-icon"><i class="bi bi-patch-check-fill"></i></div>
            <div class="award-title">ISO 9001:2015</div>
            <div class="award-org">Quality Management Certified</div>
          </div>
        </div>
      </div>
    </div>
  </section> -->

  <!-- ══════ PRICING ══════ -->
  <!-- <section class="section" id="pricing">
    <div class="container">
      <div class="text-center mb-5" data-aos="fade-up">
        <div class="section-label mx-auto"><i class="bi bi-tag-fill"></i> Pricing</div>
        <h2 class="section-title">Honest pricing.<br>No surprises, ever.</h2>
        <p class="section-sub mx-auto">Fixed-cost packages for startups, SMEs, and enterprises. Every package includes a
          dedicated manager and post-launch support.</p>
      </div>
      <div class="row g-4 justify-content-center">
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
          <div class="pricing-card">
            <div class="mb-3"><i class="bi bi-feather text-danger" style="font-size:1.4rem"></i></div>
            <div
              style="font-family:var(--display);font-weight:700;font-size:1rem;color:var(--t900);margin-bottom:.25rem">
              Starter</div>
            <div style="font-size:.82rem;color:var(--t500);margin-bottom:1.25rem">Perfect for new businesses & startups
            </div>
            <div class="price-amt">$299</div>
            <div class="price-per mb-2">one-time project</div>
            <hr style="border-color:var(--border);margin:1.25rem 0">
            <div class="pf"><i class="bi bi-check-circle-fill"></i> 5-page responsive website</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Mobile-first design</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Basic SEO setup</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> 1 month free support</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Minor changes at no cost</div>
            <div class="pf"><i class="bi bi-x-circle"></i> <span style="color:var(--t300)">eCommerce
                functionality</span></div><a href="#contact" class="btn btn-outline-soft w-100 mt-4">Get Started</a>
          </div>
        </div>
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="80">
          <div class="pricing-card featured">
            <div class="pricing-badge">Most Popular</div>
            <div class="mb-3"><i class="bi bi-lightning-charge-fill text-danger" style="font-size:1.4rem"></i></div>
            <div
              style="font-family:var(--display);font-weight:700;font-size:1rem;color:var(--t900);margin-bottom:.25rem">
              Business</div>
            <div style="font-size:.82rem;color:var(--t500);margin-bottom:1.25rem">For growing businesses ready to scale
            </div>
            <div class="price-amt">$699</div>
            <div class="price-per mb-2">one-time project</div>
            <hr style="border-color:var(--border);margin:1.25rem 0">
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Up to 15 pages</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> WordPress / WooCommerce</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Full SEO optimisation</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Speed & performance tuning</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> 3 months free support</div><a href="#contact"
              class="btn btn-brand w-100 mt-4">Start Business Plan</a>
          </div>
        </div>
        <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="160">
          <div class="pricing-card">
            <div class="mb-3"><i class="bi bi-building-fill text-danger" style="font-size:1.4rem"></i></div>
            <div
              style="font-family:var(--display);font-weight:700;font-size:1rem;color:var(--t900);margin-bottom:.25rem">
              Enterprise</div>
            <div style="font-size:.82rem;color:var(--t500);margin-bottom:1.25rem">Custom solutions for larger projects
            </div>
            <div class="price-amt" style="font-size:2rem">Custom</div>
            <div class="price-per mb-2">tailored to your needs</div>
            <hr style="border-color:var(--border);margin:1.25rem 0">
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Everything in Business</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Custom web app / portal</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> ReactJS / Node.js / Laravel</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> API integrations</div>
            <div class="pf"><i class="bi bi-check-circle-fill"></i> Priority support & SLA</div><a href="#contact"
              class="btn btn-outline-soft w-100 mt-4">Request Custom Quote</a>
          </div>
        </div>
      </div>
      <p class="text-center mt-4" style="font-size:.82rem;color:var(--t500)"><i
          class="bi bi-shield-check text-success me-1"></i> No upfront risk &nbsp;·&nbsp; No hidden charges
        &nbsp;·&nbsp; <a href="#contact" style="color:var(--red);font-weight:600">Need a custom package? Let's talk
          →</a></p>
    </div>
  </section> -->

  <!-- ══════ FAQ ══════ -->
  <section class="section faq-section" id="faq">
    <div class="container">
      <div class="row g-5 align-items-start">
        <div class="col-lg-4" data-aos="fade-right-off">
          <div class="section-label"><i class="bi bi-question-circle-fill"></i> FAQ</div>
          <h2 class="section-title">Questions we hear <span class="accent"> every day</span></h2>
          <p style="font-size:.875rem;color:var(--t500);margin-top:.75rem">Still have doubts? Email us or chat on
            WhatsApp — we reply fast.</p>
          <a href="/cdn-cgi/l/email-protection#7c0b191e191d0f0519040c190e080f3c1b111d1510521f1311"
            class="btn btn-brand mt-3"><i class="bi bi-envelope-fill me-2"></i>Email Us Now</a>
        </div>
        <div class="col-lg-8" data-aos="fade-left-off">
          <div class="faq-item"><button class="faq-q"><span>How long does a website take to build?</span><i
                class="bi bi-plus fqi"></i></button>
            <div class="faq-a">A standard 5–10 page website takes 2–3 weeks. eCommerce stores take 3–5 weeks and custom
              web applications may take 6–10 weeks depending on complexity.</div>
          </div>
          <div class="faq-item"><button class="faq-q"><span>Do you work with clients outside India?</span><i
                class="bi bi-plus fqi"></i></button>
            <div class="faq-a">Absolutely — most of our clients are international. We work with businesses in Australia,
              the US, UK, UAE, Canada, and beyond. Everything runs smoothly over email, WhatsApp, and video calls.</div>
          </div>
          <div class="faq-item"><button class="faq-q"><span>How much does a website cost?</span><i
                class="bi bi-plus fqi"></i></button>
            <div class="faq-a">Our packages start from $299 for a standard business website. eCommerce and custom
              projects are quoted based on scope. We always provide a fixed-cost quote upfront — no hourly billing
              surprises.</div>
          </div>
          <div class="faq-item"><button class="faq-q"><span>Will my website be mobile-friendly?</span><i
                class="bi bi-plus fqi"></i></button>
            <div class="faq-a">Yes, every single website we build is fully mobile responsive and tested across all major
              devices and browsers before going live.</div>
          </div>
          <div class="faq-item"><button class="faq-q"><span>What if I'm not happy with the design?</span><i
                class="bi bi-plus fqi"></i></button>
            <div class="faq-a">We offer a 100% satisfaction guarantee. If you're not happy with the initial design, we
              revise it until you're completely satisfied — at no extra cost.</div>
          </div>
          <div class="faq-item"><button class="faq-q"><span>Do you provide ongoing support after launch?</span><i
                class="bi bi-plus fqi"></i></button>
            <div class="faq-a">Yes. All packages include post-launch support. Minor changes are included at no extra
              charge. We also offer affordable monthly maintenance plans for long-term peace of mind.</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ══════ BOOK FREE MEETING — webeasy-calen ══════ -->
  <section class="webeasy-calen-section" id="book-meeting">
    <div class="container">

      <!-- Top label -->
      <div class="webeasy-calen-toprow" data-aos="fade-up">
        <div class="webeasy-calen-badge">
          <i class="bi bi-calendar-check-fill"></i> Free Consultentation
        </div>
        <h2 class="webeasy-calen-heading">
          Book a <span>Free</span> 30-Min Strategy Call
        </h2>
        <p class="webeasy-calen-sub">
          No pressure. No pitch. Just a real conversation about your website goals — pick a slot that works for you and
          we'll handle the rest.
        </p>
      </div>

      <!-- Main 2-col grid -->
      <div class="webeasy-calen-grid">

        <!-- LEFT: perks + social proof -->
        <div class="webeasy-calen-left" data-aos="fade-right-off">

          <!-- Trust pills -->
          <div class="webeasy-calen-pills">
            <div class="webeasy-calen-pill"><i class="bi bi-shield-check-fill"></i> 100% Free — No card needed</div>
            <div class="webeasy-calen-pill"><i class="bi bi-person-check-fill"></i> Talk to a senior Consultentant</div>
            <div class="webeasy-calen-pill"><i class="bi bi-clock-fill"></i> Mon–Sat · 9 AM – 8 PM IST</div>
            <div class="webeasy-calen-pill"><i class="bi bi-camera-video-fill"></i> Zoom · Google Meet · WhatsApp</div>
            <div class="webeasy-calen-pill"><i class="bi bi-file-earmark-text-fill"></i> Get a clear scope + estimate
            </div>
          </div>

          <!-- Divider -->
          <div class="webeasy-calen-divider"></div>

          <!-- Stats row -->
          <div class="webeasy-calen-stats">
            <div class="webeasy-calen-stat">
              <div class="webeasy-calen-stat-val">500<span>+</span></div>
              <div class="webeasy-calen-stat-lbl">Projects Delivered</div>
            </div>
            <div class="webeasy-calen-stat">
              <div class="webeasy-calen-stat-val">4.9<span>★</span></div>
              <div class="webeasy-calen-stat-lbl">Google Rating</div>
            </div>
            <div class="webeasy-calen-stat">
              <div class="webeasy-calen-stat-val">15<span>+</span></div>
              <div class="webeasy-calen-stat-lbl">Countries Served</div>
            </div>
          </div>

          <!-- Divider -->
          <div class="webeasy-calen-divider"></div>

          <!-- Team avatars -->
          <div class="webeasy-calen-team">
            <div class="webeasy-calen-avatars">
              <div class="webeasy-calen-av" style="background:#E53935">AK</div>
              <div class="webeasy-calen-av" style="background:#2563EB">SM</div>
              <div class="webeasy-calen-av" style="background:#16A34A">RJ</div>
              <div class="webeasy-calen-av" style="background:#D97706">VP</div>
            </div>
            <div class="webeasy-calen-team-text">
              Our team is ready — <strong>reply within 2 hours</strong>
            </div>
          </div>

          <!-- Divider -->
          <div class="webeasy-calen-divider"></div>

          <!-- Alt contact buttons -->
          <div class="webeasy-calen-alts-label">Or reach us directly</div>
          <div class="webeasy-calen-alts">
            <a href="https://wa.me/919432120437" target="_blank" class="webeasy-calen-alt-btn webeasy-calen-alt-wa">
              <i class="bi bi-whatsapp"></i> WhatsApp
            </a>
            <a href="tel:+919432120437" class="webeasy-calen-alt-btn webeasy-calen-alt-ph">
              <i class="bi bi-telephone-fill"></i> Call Us
            </a>
            <a href="mailto:webeasyexperts@gmail.com" class="webeasy-calen-alt-btn webeasy-calen-alt-em">
              <i class="bi bi-envelope-fill"></i> Email
            </a>
          </div>

        </div>

        <!-- RIGHT: Calendly embed card -->
        <div class="webeasy-calen-right" data-aos="fade-left-off">
          <div class="webeasy-calen-card">

            <!-- Card header -->
            <div class="webeasy-calen-card-head">
              <div class="webeasy-calen-card-icon"><i class="bi bi-calendar3"></i></div>
              <div>
                <div class="webeasy-calen-card-title">Schedule Your Free Consultentation</div>
                <div class="webeasy-calen-card-sub">Pick a time — instant confirmation sent to your email</div>
              </div>
              <!-- Live badge -->
              <div class="webeasy-calen-live-badge">
                <span class="webeasy-calen-live-dot"></span> Live Availability
              </div>
            </div>

            <!-- Calendly inline embed -->
            <div class="webeasy-calen-embed-wrap">
              <div class="calendly-inline-widget" data-url="https://calendly.com/webeasyexperts/30min"
                style="min-width:280px;height:490px;">
              </div>
              <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
            </div>

            <!-- Card footer -->
            <div class="webeasy-calen-card-foot">
              <i class="bi bi-lock-fill"></i> Secured by Calendly &nbsp;·&nbsp;
              <i class="bi bi-shield-check-fill text-success"></i> No payment required
            </div>

          </div>
        </div>

      </div>
    </div>
  </section>
  <!-- ══════ CONTACT ══════ -->
  <section class="wexpert-contact-section" id="contact">
    <div class="container">
      <!-- Header -->
      <div class="wexpert-contact-header" data-aos="fade-up">
        <div class="wexpert-contact-badge"><i class="bi bi-envelope-fill"></i> Get In Touch</div>
        <h2 class="wexpert-contact-heading">Let's build <span class="accent accent-red">your website</span><br>the right
          way</h2>
        <p class="wexpert-contact-sub">Free Consultentation. Fixed price. 100% satisfaction guarantee — or we keep
          working
          till you're happy.</p>
      </div>

      <!-- Grid -->
      <div class="wexpert-contact-grid" data-aos="fade-up">

        <!-- Left info -->
        <div class="wexpert-contact-info">
          <div class="wexpert-contact-info-heading">Talk to us directly</div>
          <p class="wexpert-contact-info-sub">No middlemen, no delays. Reach out on any platform and we'll get back to
            you within 2 hours.</p>

          <div class="wexpert-contact-item">
            <div class="wexpert-contact-item-icon"><i class="bi bi-whatsapp"></i></div>
            <div>
              <div class="wexpert-contact-item-title">WhatsApp</div>
              <div class="wexpert-contact-item-val">+91 94321 20437<br>Mon–Sat, 9 AM – 8 PM IST</div>
            </div>
          </div>

          <div class="wexpert-contact-item">
            <div class="wexpert-contact-item-icon"><i class="bi bi-envelope-fill"></i></div>
            <div>
              <div class="wexpert-contact-item-title">Email Us</div>
              <div class="wexpert-contact-item-val">webeasyexperts@gmail.com<br>We reply within 2 hours</div>
            </div>
          </div>

          <div class="wexpert-contact-item">
            <div class="wexpert-contact-item-icon"><i class="bi bi-globe2"></i></div>
            <div>
              <div class="wexpert-contact-item-title">Serving Worldwide</div>
              <div class="wexpert-contact-item-val">Australia · USA · UK · UAE · Canada<br>And many more countries</div>
            </div>
          </div>

        </div>

        <!-- Right form -->
        <form class="wexpert-contact-form-wrap w3-form" data-aos="fade-left-off">
          <input type="hidden" name="access_key" value="15c4b0e4-e0e7-47ca-91c6-e88f83db9a74">
          <input type="hidden" name="subject" value="New Contact Form Submission - Homepage">

          <div class="wexpert-contact-row">
            <div class="wexpert-contact-field">
              <label class="wexpert-contact-label">Your Name <span>*</span></label>
              <input type="text" class="wexpert-contact-input" name="name" placeholder="John Smith" required />
            </div>
            <div class="wexpert-contact-field">
              <label class="wexpert-contact-label">Phone / WhatsApp <span>*</span></label>
              <input type="tel" class="wexpert-contact-input" name="phone" placeholder="+1 234 567 8900" required />
            </div>
          </div>

          <div class="wexpert-contact-field">
            <label class="wexpert-contact-label">Email Address <span>*</span></label>
            <input type="email" class="wexpert-contact-input" name="email" placeholder="john@yourcompany.com" required />
          </div>

          <div class="wexpert-contact-field">
            <label class="wexpert-contact-label">Message <span>*</span></label>
            <textarea class="wexpert-contact-input" name="message" placeholder="Tell us about your project..." required></textarea>
          </div>

          <button type="submit" class="wexpert-contact-btn">
            Send Message <i class="bi bi-arrow-right"></i>
          </button>

          <p class="wexpert-contact-note">
            <i class="bi bi-shield-check text-success me-1"></i>
            We respond within 2 hours on business days. No spam, ever.
          </p>

        </form>
      </div>
    </div>
  </section>

  <!-- ══════ GLOBAL PRESENCE — Country carousel ══════ -->
  <section class="section" id="global-presence" style="background:var(--subtle);border-top:1px solid var(--border)">
    <div class="container">
      <div class="text-center mb-4" data-aos="fade-up">
        <div class="section-label d-inline-flex"><i class="bi bi-globe-asia-australia"></i> Serving Businesses
          Worldwide</div>
        <h2 class="section-title">Hire Indian Web Developers <span class="accent">Wherever You Are</span></h2>
        <p class="section-sub mx-auto" style="max-width:600px">Affordable, high-quality website design and
          development — built by an experienced Indian web team for businesses around the world.</p>
      </div>

      <div id="countryCarousel" class="carousel slide wcountry-carousel" data-bs-ride="carousel"
        data-aos="fade-up" data-aos-delay="100">
        <div class="carousel-inner">

          <div class="carousel-item active">
            <div class="wcountry-card">
              <div class="wcountry-flag">🇦🇺</div>
              <div class="wcountry-body">
                <h3>Hire Indian Web Developers <span class="accent">for Your Australian Business</span></h3>
                <p>Affordable, high-quality website design and development for Australian businesses — built by
                  an experienced Indian web team.</p>
                <a href="hire-indian-website-designers-developers-australia.php"
                  class="btn btn-brand d-inline-flex align-items-center gap-2">See Our Australia Page <i
                    class="bi bi-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="wcountry-card">
              <div class="wcountry-flag">🇺🇸</div>
              <div class="wcountry-body">
                <h3>Hire Indian Web Developers <span class="accent">for Your US Business</span></h3>
                <p>A dedicated page for our US clients is on its way — same quality, same team, same commitment.
                </p>
                <span class="wcountry-soon"><i class="bi bi-hourglass-split"></i> Coming Soon</span>
              </div>
            </div>
          </div>

          <div class="carousel-item">
            <div class="wcountry-card">
              <div class="wcountry-flag">🇬🇧</div>
              <div class="wcountry-body">
                <h3>Hire Indian Web Developers <span class="accent">for Your UK Business</span></h3>
                <p>A dedicated page for our UK clients is on its way — same quality, same team, same commitment.
                </p>
                <span class="wcountry-soon"><i class="bi bi-hourglass-split"></i> Coming Soon</span>
              </div>
            </div>
          </div>

        </div>

        <button id="countryPrev" type="button" class="wcountry-control wcountry-control-prev" aria-label="Previous">
          <i class="bi bi-chevron-left"></i>
        </button>
        <button id="countryNext" type="button" class="wcountry-control wcountry-control-next" aria-label="Next">
          <i class="bi bi-chevron-right"></i>
        </button>

        <div class="wcountry-indicators">
          <button type="button" class="active" aria-label="Slide 1"></button>
          <button type="button" aria-label="Slide 2"></button>
          <button type="button" aria-label="Slide 3"></button>
        </div>
      </div>
    </div>
  </section>

  <style>
    .wcountry-carousel {
      position: relative;
      padding: 0 60px;
    }

    .wcountry-card {
      display: flex;
      align-items: center;
      gap: 2rem;
      background: var(--white);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 2.5rem;
      min-height: 220px;
    }

    .wcountry-flag {
      font-size: 4.5rem;
      line-height: 1;
      flex-shrink: 0;
    }

    .wcountry-body h3 {
      font-family: var(--display);
      font-size: 1.4rem;
      font-weight: 800;
      color: var(--t900);
      margin-bottom: 0.6rem;
    }

    .wcountry-body h3 .accent {
      color: var(--red);
    }

    .wcountry-body p {
      color: var(--t500);
      margin-bottom: 1.2rem;
      max-width: 560px;
    }

    .wcountry-soon {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      background: var(--subtle);
      color: var(--t500);
      font-weight: 600;
      font-size: 0.85rem;
      padding: 0.5rem 1rem;
      border-radius: 999px;
    }

    .wcountry-control {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      width: 44px;
      height: 44px;
      border-radius: 50%;
      border: 1px solid var(--border);
      background: var(--white);
      color: var(--t900);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.1rem;
      z-index: 2;
      cursor: pointer;
      transition: 0.2s;
    }

    .wcountry-control:hover {
      background: var(--red);
      color: #fff;
      border-color: var(--red);
    }

    .wcountry-control-prev {
      left: 0;
    }

    .wcountry-control-next {
      right: 0;
    }

    .wcountry-indicators {
      display: flex;
      justify-content: center;
      gap: 0.5rem;
      margin-top: 1.5rem;
    }

    .wcountry-indicators button {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      border: none;
      background: var(--muted);
      padding: 0;
      cursor: pointer;
    }

    .wcountry-indicators button.active {
      background: var(--red);
      width: 22px;
      border-radius: 4px;
      transition: 0.2s;
    }

    @media (max-width: 767px) {
      .wcountry-carousel {
        padding: 0 46px;
      }

      .wcountry-card {
        flex-direction: column;
        text-align: center;
        padding: 1.75rem;
      }

      .wcountry-body p {
        margin-left: auto;
        margin-right: auto;
      }
    }
  </style>

  <script>
    document.addEventListener("DOMContentLoaded", function () {
      var carouselEl = document.getElementById("countryCarousel");
      if (!carouselEl || typeof bootstrap === "undefined") return;
      var carousel = bootstrap.Carousel.getOrCreateInstance(carouselEl, { interval: 6000 });
      var indicators = carouselEl.querySelectorAll(".wcountry-indicators button");

      document.getElementById("countryPrev").addEventListener("click", function () { carousel.prev(); });
      document.getElementById("countryNext").addEventListener("click", function () { carousel.next(); });
      indicators.forEach(function (btn, i) {
        btn.addEventListener("click", function () { carousel.to(i); });
      });
      carouselEl.addEventListener("slide.bs.carousel", function (e) {
        indicators.forEach(function (btn, i) { btn.classList.toggle("active", i === e.to); });
      });
    });
  </script>

  <!-- ══════ BLOG — New featured + grid layout ══════ -->
  <section class="section blog-section" id="blog">
    <div class="container">
      <div class="blog-section-header" data-aos="fade-up">
        <div>
          <div class="section-label"><i class="bi bi-journal-richtext"></i> Blog & Insights</div>
          <h2 class="section-title" style="max-width:420px">Tips & strategies<br>from <span class="accent"> our
              team</span></h2>
        </div>
        <a href="#" class="btn btn-outline-soft d-inline-flex align-items-center gap-2">View All Articles <i
            class="bi bi-arrow-right"></i></a>
      </div>

      <div class="row g-4" data-aos="fade-up">
        <!-- Featured large card -->
        <div class="col-lg-5">
          <a href="#" class="blog-feat d-block">
            <div class="blog-feat-bg"></div>
            <div class="blog-feat-img"><i class="bi bi-search"></i></div>
            <div class="blog-feat-content">
              <div class="blog-feat-tag">SEO</div>
              <div class="blog-feat-title">How to Rank on Google in India — A 2026 Complete Guide for Small Businesses
              </div>
              <div class="blog-feat-desc">Local SEO, Hindi keyword research, and Google Business Profile tips that
                actually work in the Indian market.</div>
              <div class="blog-feat-meta">
                <div class="blog-feat-av">RJ</div>
                <span>Riya Joshi</span>
                <span>·</span>
                <span>8 min read</span>
                <span>·</span>
                <span>Mar 10, 2026</span>
              </div>
            </div>
          </a>
        </div>

        <!-- 4 smaller cards in 2x2 grid -->
        <div class="col-lg-7">
          <div class="row g-3 h-100">
            <div class="col-sm-6">
              <a href="blog/shopify-website-developer-india.php" class="blog-sm d-flex">
                <div><span class="blog-sm-tag tag-branding">eCommerce</span></div>
                <div class="blog-sm-title">Shopify Website Developer India: Why Hiring the Right Expert Can
                  Transform Your Online Business</div>
                <div class="blog-sm-desc">Why businesses worldwide hire Shopify developers in India — services,
                  costs, and how to choose the right partner.</div>
                <div class="blog-sm-meta">
                  <div class="blog-sm-av" style="background:#D97706">WE</div>
                  <span>Web EASY Experts Team</span><span>·</span><span>11 min</span>
                </div>
              </a>
            </div>
            <div class="col-sm-6">
              <a href="blog/web-experts-vs-website-experts.php" class="blog-sm d-flex">
                <div><span class="blog-sm-tag tag-web">Web Development</span></div>
                <div class="blog-sm-title">Web Experts vs Website Experts: Why Choosing the Right Professional Matters</div>
                <div class="blog-sm-desc">Confused between a web expert and a website expert? Here's what the
                  difference actually means for your business.</div>
                <div class="blog-sm-meta">
                  <div class="blog-sm-av" style="background:#16A34A">WE</div>
                  <span>Web EASY Experts Team</span><span>·</span><span>10 min</span>
                </div>
              </a>
            </div>
            <div class="col-sm-6">
              <a href="blog/how-web-experts-make-your-website-user-friendly.php" class="blog-sm d-flex">
                <div><span class="blog-sm-tag tag-web">Web Design</span></div>
                <div class="blog-sm-title">How Web Experts Make Your Website User-Friendly</div>
                <div class="blog-sm-desc">What actually makes a website easy to use — from navigation and speed to
                  mobile responsiveness.</div>
                <div class="blog-sm-meta">
                  <div class="blog-sm-av" style="background:#EA580C">WE</div>
                  <span>Web EASY Experts</span><span>·</span><span>8 min</span>
                </div>
              </a>
            </div>
            <div class="col-sm-6">
              <a href="blog/wordpress-developers-india.php" class="blog-sm d-flex">
                <div><span class="blog-sm-tag tag-seo">WordPress</span></div>
                <div class="blog-sm-title">WordPress Developers India: Why Businesses Worldwide Choose Indian
                  WordPress Experts</div>
                <div class="blog-sm-desc">Why businesses worldwide choose Indian WordPress developers — services,
                  benefits, and how to pick the right partner.</div>
                <div class="blog-sm-meta">
                  <div class="blog-sm-av" style="background:#2563EB">WE</div>
                  <span>Web EASY Experts Team</span><span>·</span><span>7 min</span>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- ══════ CTA ══════ -->
  <section class="cta-section">
    <div class="container" data-aos="fade-up">
      <div class="cta-box">
        <div class="position-relative" style="z-index:1">
          <div class="section-label mx-auto mb-4"
            style="background:rgba(255,255,255,.1);color:rgba(255,255,255,.85);border:none"><i
              class="bi bi-rocket-takeoff-fill"></i> Ready to get started?</div>
          <h2>Connect with Our Website Experts <br>For Free Consultentation</h2>
          <p>Create a powerful website with professional designers and developers from India.</p>
          <div class="d-flex flex-wrap gap-3 justify-content-center">
            <a href="#contact" class="btn btn-brand-lg">Schedule Free Consultentation <i
                class="bi bi-arrow-right ms-2"></i></a>
            <a href="https://wa.me/919432120437" class="btn"
              style="background:rgba(255,255,255,0.1);color:#fff;border:1px solid rgba(255,255,255,.2);font-family:var(--display);font-weight:600;padding:.85rem 2rem;border-radius:12px;font-size:1rem;transition:background .2s"
              target="_blank"><i class="bi bi-whatsapp me-2"></i> WhatsApp Us</a>
          </div>
          <div class="mt-4"
            style="font-size:.82rem;color:#475569;display:flex;align-items:center;justify-content:center;gap:1.5rem;flex-wrap:wrap">
            <span><i class="bi bi-check2-circle me-1" style="color:#4ADE80"></i>100% Satisfaction Guarantee</span>
            <span><i class="bi bi-check2-circle me-1" style="color:#4ADE80"></i>No upfront risk</span>
            <span><i class="bi bi-check2-circle me-1" style="color:#4ADE80"></i>Fixed-price packages</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ══════ FOOTER — Callback strip + multi-column dark footer ══════ -->
  <!-- ══════ REQUEST CALLBACK STRIP ══════ -->
  <div class="callback-strip">
    <div class="container">
      <div class="row align-items-center g-4">
        <div class="col-lg-5" data-aos="fade-right-off">
          <div class="callback-strip-label">Request a Callback</div>
          <h4>Get a free call from our web experts</h4>
          <p>Leave your number — we'll call you back within 2 hours during business hours.</p>
        </div>
        <div class="col-lg-7" data-aos="fade-left-off">
          <form class="callback-form w3-form">
            <input type="hidden" name="access_key" value="15c4b0e4-e0e7-47ca-91c6-e88f83db9a74">
            <input type="hidden" name="subject" value="New Callback Request - Homepage">
            <input type="text" class="callback-input" name="name" placeholder="Your Name" required />
            <input type="tel" class="callback-input" name="phone" placeholder="Phone / WhatsApp" required />
            <select class="callback-input fc-select" name="service"
              style="color:#475569;background-image:url('data:image/svg+xml,%3csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 16 16%22%3e%3cpath fill=%2264748b%22 d=%22M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z%22/%3e%3c/svg%3e');background-repeat:no-repeat;background-position:right 0.85rem center;background-size:12px;padding-right:2.5rem">
              <option value="">Service needed...</option>
              <option>Website Design</option>
              <option>eCommerce Store</option>
              <option>SEO Services</option>
              <option>Google / Meta Ads</option>
              <option>Logo & Branding</option>
            </select>
            <button type="submit" class="callback-btn"><i class="bi bi-telephone-fill me-2"></i>Request Callback</button>
          </form>
          <p style="font-size:0.72rem;color:#c4cad3;margin-top:0.6rem;margin-bottom:0"><i
              class="bi bi-lock-fill me-1"></i> Your details are 100% private. No spam, ever.</p>
        </div>
      </div>
    </div>
  </div>
  <!-- ===================================================================================== -->
  <!-- Main footer -->
  <?php include $base . "footer.php"; ?>
</body>

</html>